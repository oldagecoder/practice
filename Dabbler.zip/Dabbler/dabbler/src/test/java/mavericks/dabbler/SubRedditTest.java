package mavericks.dabbler;


import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SubRedditTest {
	WebDriver driver;
	Home homeObj ;
	Login loginObj;
	SubReddit subRedditObj; 
	
	@BeforeTest
	public void setup() throws InterruptedException {
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("profile.default_content_setting_values.notifications", 2);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\watts\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    subRedditObj = new SubReddit(driver);
	    homeObj = new Home(driver); 
	    loginObj = new Login(driver);
		driver.get("http://reddit.com");
		subRedditObj = new SubReddit(driver);
		loginObj = new Login(driver);
		loginObj.login("mavdabbler","mavdabblerismavdabbler");
	}
	
	@AfterClass(description = "Exit code")
	public void ExitTest() {
		System.out.println("===EXIT TEST===");
		driver.close();
	}
	
	@BeforeMethod
	public void beforeEveryTestCase(Method method) {
		System.out.println("==="+method.getName()+"===");
	}
	
	@Test(priority=1)
	void commentOnAPost() {
		Date objDate = new Date();	
		String strDateFormat = "dd MMM YYYY h:mma"; //Date format is Specified
		SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); //Date format string is passed as an argument to the Date format object
		String currentDate = objSDF.format(objDate);
		String commentToEnter = currentDate + " J Watts";
		System.out.println(commentToEnter);
		homeObj.clickNavigation();
		homeObj.filterMySubReddits("r/MavericksDnD");
		List<WebElement> lis = homeObj.fetchMenuItems();
		lis.get(0).click();
		subRedditObj.checkIfSubscribed();
		subRedditObj.enterSearchText("Mavericks QA Assignment - 2019");
		subRedditObj.clickOnSearchedPost();
		subRedditObj.enterComment(commentToEnter);
		subRedditObj.pushComment();
		List<WebElement> comments  =subRedditObj.fetchPostedComment();
		Assert.assertEquals(comments.get(0).getText(),"just now");
	}
	
	@Test (priority=2,dependsOnMethods={"commentOnAPost"})
	public void upVoteAPopularPost() throws InterruptedException{
		WebElement vote = subRedditObj.getUpVoteElement();
		System.out.println(vote.getAttribute("aria-pressed").toString());
		if(vote.getAttribute("aria-pressed").toString().equals("false")) {
			vote.click();
		}
		else {
			System.out.println("Post is already Upvoted");
		}
		Assert.assertEquals(vote.getAttribute("aria-pressed").toString(),"true");
	}
	
	@Test (priority=3,dependsOnMethods={"commentOnAPost"})
	public void downVoteAPost(){
		WebElement vote = subRedditObj.getDownVoteElement();
		System.out.println(vote.getAttribute("aria-pressed").toString());
		if(vote.getAttribute("aria-pressed").toString().equals("false")) {
			System.out.println(vote.getAttribute("aria-pressed").toString());
			vote.click();
		}
		else {
			System.out.println(vote.getAttribute("aria-pressed").toString());
			System.out.println("Post is already Downvoted");
		}
		Assert.assertEquals(vote.getAttribute("aria-pressed").toString(),"true");
	}
}
