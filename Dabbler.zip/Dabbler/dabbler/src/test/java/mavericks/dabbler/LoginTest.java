package mavericks.dabbler;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

//import resources.Home;
//import Login;

public class LoginTest {

	WebDriver driver;
	Login loginObj;
	//Home homeObj;
	WebDriverWait wait;
//	public void setup(String browser) {
//		switch (browser) {
//		case "ie":
//			driver = new ChromeDriver();
//			break;
//		case "firefox":
//			driver = new ChromeDriver();
//			break;
//		default:
//			driver = new ChromeDriver();
//		}
//	}

	@AfterClass(description = "Exit code")
	public void ExitTest() {
		System.out.println("===EXIT TEST===");
		driver.close();
	}

    @Parameters({"driverPath"})
	@BeforeTest
	public void beforeClass(String driverP) {
//		public void beforeClass() {
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("profile.default_content_setting_values.notifications", 2);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);
		System.setProperty("webdriver.chrome.driver", driverP);
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://reddit.com");
	}
	
	@BeforeMethod
	public void beforeMethod(Method method){
		System.out.println("==="+method.getName()+"===");
	}
	
	@Test
	public void loginTest() throws InterruptedException {
		loginObj = new Login(driver);
		//homeObj = new Home(driver);
		loginObj.clickLogin();
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@src='https://www.reddit.com/login/']")));
		
		loginObj.enterUserName("mavdabbler");
		loginObj.enterPassword("mavdabblerismavdabbler");
		loginObj.clickSignIn();
		//Assert.assertTrue(homeObj.userDropdown.getText().contains("mavdabbler"));

	}  
}
