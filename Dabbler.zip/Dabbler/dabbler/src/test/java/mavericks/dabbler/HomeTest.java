package mavericks.dabbler;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class HomeTest {
	WebDriver driver ;
	Login loginObj;
	Home homeObj;

	@BeforeClass
	void setup() throws InterruptedException {
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("profile.default_content_setting_values.notifications", 2);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\watts\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://reddit.com");
		loginObj = new Login(driver);
		loginObj.login("mavdabbler","mavdabblerismavdabbler");
	}
	
	@AfterClass(description = "Exit code")
	public void exitTest() throws InterruptedException {
		System.out.println("===EXIT TEST===");
		driver.close();
	}
	
	@BeforeMethod
	public void beforeMethod(Method method){
		System.out.println("==="+method.getName()+"===");
	}
	
	@Test
	public void seeSubscribedReddits() {
		boolean flag = false;
		homeObj = new Home(driver);
		homeObj.clickNavigation();
		homeObj.filterMySubReddits("r/");
		List<WebElement> lis = homeObj.fetchMenuItems();
		for(WebElement element:lis){
			if(element.getAttribute("aria-label").toString().contentEquals("r/MavericksDnD")) {
				flag = true;
			}
		}
		Assert.assertTrue(flag);
		homeObj.clickNavigation();
	}

	@Test
	public void viewSubscribedReddit() throws InterruptedException {
		SubReddit subRedditObj = new SubReddit(driver);
		homeObj = new Home(driver);
		homeObj.clickNavigation();
		homeObj.filterMySubReddits("r/MavericksDnD");
		List<WebElement> subscribedRedits = homeObj.fetchMenuItems();
		subscribedRedits.get(0).click();
		Assert.assertTrue(subRedditObj.checkIfSubscribed().isDisplayed()); 

	}
}
