package mavericks.dabbler;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Login {
	WebDriver driver;

	@FindBy(xpath="//a[contains(text(),'log in')]" )
	WebElement loginButton;
	
	@FindBy(xpath="//input[@id='loginUsername']")
	public WebElement iD;

	@FindBy(id = "loginPassword")
	WebElement password;

	@FindBy(className = "AnimatedForm__submitButton")
	WebElement signIn;
	
	public Login(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void clickLogin() {
		loginButton.click();
	}

	public void clickSignIn() {
		signIn.click();
	}

	public WebElement getIDElement() {
		return iD;
	}
	
	public void enterUserName(String userName) {
		iD.click(); 
		iD.sendKeys(userName);
	}

	public void enterPassword(String pwd) {
		password.sendKeys(pwd);
	}
	
	public void login(String id, String pwd) throws InterruptedException {
		clickLogin();
		
		System.out.println("===================================================================================");
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@src='https://www.reddit.com/login/']")));
		enterUserName(id);
		enterPassword(pwd);
		clickSignIn();
	}
	
}
