package mavericks.dabbler;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SubReddit {
WebDriver driver;

	@FindBy(xpath = "//button[@type='subreddit']")
	WebElement subRedditJoined;
	
	@FindBy(id="header-search-bar")
	WebElement searchbar;
	
	@FindBy(xpath= "//div//em[contains(text(),'QA Assignment - 2019')]")
	WebElement qaAssignmentPost;
	
	@FindBy(xpath="//div[@class='notranslate public-DraftEditor-content']")
	public WebElement commentBox;
	
	@FindBy(xpath="//div/button[contains(text(),'comment')]")
	WebElement submitComment;
	
	@FindBy(xpath="CommentSort--SortPicker")
	WebElement sortComments;	
	
	@FindBy(xpath="//a/button//span[contains(text(),'new')]")
	WebElement sortByNewComments;
	
	@FindBy(xpath="//div//span[contains(text(),'just now')]")
	List<WebElement> comments;
	
	@FindBy(xpath="//div[@data-test-id='post-content']//button[@data-click-id='upvote']")
	WebElement upVote;
	
	@FindBy(xpath="//div[@data-test-id='post-content']//button[@data-click-id='downvote']")
	WebElement downVote;

	public WebElement getUpVoteElement() {
		return upVote;
	}
	
	public WebElement getDownVoteElement() {
		return downVote;
	}
	
	public SubReddit(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement checkIfSubscribed() {
		return subRedditJoined;
	}
	
	public void enterSearchText(String str) {
		searchbar.sendKeys(str);
		searchbar.sendKeys(Keys.ENTER);
	}
	
	public void clickOnSearchedPost() {
		qaAssignmentPost.click();
	}
	
	public void enterComment(String str) {
		commentBox.click();
		commentBox.sendKeys(str);
	}
	
	public void pushComment() {
		submitComment.click();
	}
	
	public void sortTheCommentsByNew() {
		sortComments.click();
		sortByNewComments.click();
	}
	
	public List<WebElement> fetchPostedComment() {
		return comments;
	}
}
