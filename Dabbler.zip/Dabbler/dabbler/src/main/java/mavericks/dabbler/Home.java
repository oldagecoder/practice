package mavericks.dabbler;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

public class Home {
	WebDriver driver;
	
	@FindBy(xpath = "//button[@id='USER_DROPDOWN_ID']//div")
	public WebElement userDropdown;
	
	@FindBy(xpath="//button[@role='navigation']")
	WebElement navigationMenu;
	
	@FindBy(id="header-subreddit-filter")
	WebElement filter;

	
	@FindBy(xpath="//div[@role='menu']//a[@role='menuitem']")
	List<WebElement> menuItems;
//
	@FindBy(xpath="//a[@aria-label='Home']")
	WebElement Home;
	
	public Home(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void clickNavigation() {
		navigationMenu.click();
	}
	
	public void filterMySubReddits(String str) {
		filter.sendKeys(str);
	}
	
	public List<WebElement> fetchMenuItems() {
		return menuItems;
	}
}
