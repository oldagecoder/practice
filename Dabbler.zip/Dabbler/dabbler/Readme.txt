** ********************************************************
** Suite is specifically designed for Chrome browser.     *
** Integrated with Maven                                  *  
** Concept : Page object model                            *  
** This suite accepts driverPath as command line argument.*
** ********************************************************
** Tools Used: Selenium, Eclipse                          *
** Dependency Management: Maven                           *
** FrameWork: TestNG                                      *
** ********************************************************
** Pre-Requisite:                                         *
** 1. Maven                                               *
** 2. JDK                                                 *
** ********************************************************

How to run test suite:
(cd to directory /dabbler/pom.xml) and run
mvn test -DdriverPath="path_to_chromedriver.exe"

Where to view reports:
* /dabbler/target/surefire-reports/index.html


Overview:
-------------------------------------------------------------------------------------------
Automated functional UI test suite to test reddit.com
Features : 
	- As a user I can login.
	- As a user I am able to see my subscribed subreddits.
	- As a user I am able to view one of my subscribed subreddits.
	- As a user I am able to create a comment on a post. The comment should have the
	  current date time and my name.
	  Eg: “25 Jan 2018 3:30pm John Doe”
	- As a user I am able to upvote a post.
	- As a user I am able to downvote a post.
-------------------------------------------------------------------------------------------	